## pyedo
## 
## @file SDK_python.py
## @author  Comau
## @version 0.7
## @date 25.07.2022
## 

__author__ = u'Comau'
__version__ = (0, 7, 0)
