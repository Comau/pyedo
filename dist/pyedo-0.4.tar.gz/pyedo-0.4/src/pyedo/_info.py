## pyedo
## 
## @file SDK_python.py
## @author  Comau
## @version 2.0
## @date 15.07.2021
## 

__author__ = u'Comau'
__version__ = (2, 0, 0)
