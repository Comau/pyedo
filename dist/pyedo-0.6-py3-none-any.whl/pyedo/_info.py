## pyedo
## 
## @file SDK_python.py
## @author  Comau
## @version 0.6
## @date 09.11.2021
## 

__author__ = u'Comau'
__version__ = (0, 6, 0)
